from src.query import *

if __name__ == '__main__':
    ask_query("[[Special status::Introduced]]", "introduced_taxa.csv")
