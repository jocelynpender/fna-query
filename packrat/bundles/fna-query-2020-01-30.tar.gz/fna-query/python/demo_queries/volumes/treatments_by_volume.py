from src.query import *

if __name__ == '__main__':
    ask_query("[[Volume::Volume 17]]", "taxa_volume_17.csv")
