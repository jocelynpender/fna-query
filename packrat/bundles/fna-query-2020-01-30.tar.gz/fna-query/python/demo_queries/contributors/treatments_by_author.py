from src.query import *

if __name__ == '__main__':
    ask_query("[[Author::Bruce A. Ford]]", "treatments_by_bruce_a_ford.csv")
