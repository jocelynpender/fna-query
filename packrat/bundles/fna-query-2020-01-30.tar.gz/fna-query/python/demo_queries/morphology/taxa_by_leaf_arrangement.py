from src.query import *

if __name__ == '__main__':
    ask_query("[[Leaf arrangement::alternate]]", "taxa_with_alternate_leaves.csv")
