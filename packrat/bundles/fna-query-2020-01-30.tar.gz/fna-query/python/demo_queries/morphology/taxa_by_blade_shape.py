from src.query import *

if __name__ == '__main__':
    ask_query("[[Blade shape::elliptic]]", "taxa_with_elliptic_blades.csv")
