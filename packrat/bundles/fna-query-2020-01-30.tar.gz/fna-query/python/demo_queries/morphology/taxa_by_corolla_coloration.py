from src.query import *

if __name__ == '__main__':
    ask_query("[[Corolla coloration::yellow]]", "taxa_with_yellow_corolla.csv")
