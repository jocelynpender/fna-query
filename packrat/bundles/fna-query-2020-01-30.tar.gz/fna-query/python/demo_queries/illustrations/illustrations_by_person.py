from src.query import *

if __name__ == '__main__':
    ask_query("[[Illustrator::Annaliese Miller]][[Illustration::Present]]", "annaliese_miller_illustrations.csv")
