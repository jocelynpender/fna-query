from src.query import *

if __name__ == '__main__':
    ask_query("[[Taxon parent::Carex]]", "carex_lower_taxa.csv")
