from src.query import *

if __name__ == '__main__':
    ask_query("[[Taxon rank::+]]", "all_taxa_in_fna.csv")
