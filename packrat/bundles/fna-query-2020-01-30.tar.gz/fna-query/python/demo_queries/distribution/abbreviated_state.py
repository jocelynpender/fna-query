from src.query import *

if __name__ == '__main__':
    ask_query("[[Distribution::Nunavut]]", "nunavut_taxa.csv")
