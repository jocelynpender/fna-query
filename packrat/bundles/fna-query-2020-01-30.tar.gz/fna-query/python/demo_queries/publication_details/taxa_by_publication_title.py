from src.query import *

if __name__ == '__main__':
    ask_query("[[Publication title::Proc. Amer. Acad. Arts]]", "taxa_in_proc_amer_acad_arts.csv")
