from src.query import *

if __name__ == '__main__':
    ask_query("[[Publication year::1990]]", "taxa_published_1990.csv")
