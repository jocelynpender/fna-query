# Query the Flora of North America Semantic MediaWiki

## Getting started

You can use R or Python to programmatically query the Flora of North America. 

### R

This section assumes you are familiar with the R programming language. 

#### Prerequisites

* R 
* WikipediR

`install.packages("WikipediR")`

* tidyverse

`install.packages("tidyverse")`

* Or get started using packrat

`install.packages("packrat")`


Usage:

Expected output:

### Python

This section assumes you are familiar with Python programming. 



## 

### Semantic MediaWiki semantic search syntax

Semantic MediaWiki Query Syntax
https://www.semantic-mediawiki.org/wiki/Help:Semantic_search
https://www.semantic-mediawiki.org/wiki/Help:Searc


## Getting help



### Prerequisites

* You'll need to have a query in mind to run... unless you just want to run the demo queries


### Run a demo query to ensure you're all set up properly


h_operators


## Support

jocelyn.pender@canada.ca

### Bug reports

https://github.com/jocelynpender/fna-query/issues

## Resources





Merging Multiple CSV Files
R script for merging multiple CSV files.


**TODO:**
improve inline documentation in my script (R & Python): e.g, what are properties_texts???

## Python

You need to have a log-in to use the API via Python

Create a file called local.py with your credentials

https://mwclient.readthedocs.io/en/latest/index.html

## R

Steps:
(1) Open an R console
(2) Open the [https://github.com/jocelynpender/fna-query/blob/master/R/src/run_query.R](run_query.R) script
(3) There are two different functions to be aware of, depending on your needs:

`ask_query_titles`
Returns only a list of Taxon names that match your query


`properties_texts_data_frame`
Returns a list of Taxon names **and** associated properties asked for by your query


### Further information

The scripts leverage the [https://cran.r-project.org/web/packages/WikipediR/WikipediR.pdf](WikipediR package for R). 
