source("../../src/query.R")

ask_query_titles("[[Taxon family::Asteraceae]][[Taxon rank::section]]", "asteraceae_sections.csv")
