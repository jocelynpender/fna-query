source("../../src/query.R")

ask_query_titles("[[Taxon rank::species]]", "all_species_in_fna.csv")
