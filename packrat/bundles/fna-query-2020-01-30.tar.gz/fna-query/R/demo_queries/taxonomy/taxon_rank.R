source("../../src/query.R")

ask_query_titles("[[Taxon rank::+]]", "all_taxa_in_fna.csv")
