source("../../src/query.R")

ask_query_titles("[[Illustrator::Annaliese Miller]][[Illustration::Present]]", "annaliese_miller_illustrations.csv")
