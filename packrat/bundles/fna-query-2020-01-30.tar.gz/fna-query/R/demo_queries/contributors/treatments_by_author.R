source("../../src/query.R")

ask_query_titles("[[Author::Bruce A. Ford]]", "treatments_by_bruce_a_ford.csv")
