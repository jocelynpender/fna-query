source("../../src/query.R")

ask_query_titles("[[Publication title::Proc. Amer. Acad. Arts]]", "taxa_in_proc_amer_acad_arts.csv")
