source("../../src/query.R")

ask_query_titles("[[Publication year::>>1990]]", "taxa_published_after_1990.csv")
